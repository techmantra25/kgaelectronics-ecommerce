<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Interfaces\UserInterface;
use App\Interfaces\OrderInterface;
use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Address;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use PharIo\Manifest\Url;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Mail\OtpMail;




class UserController extends Controller
{
    public function __construct(UserInterface $userRepository, OrderInterface $orderRepository)
    {
        $this->userRepository = $userRepository;
        $this->orderRepository = $orderRepository;
    }

    public function login(Request $request)
    {
        $back_url = url()->previous();
        $recommendedProducts = $this->userRepository->recommendedProducts();
        return view('front.auth.login', compact('recommendedProducts','back_url'));
    }

    // public function register(Request $request)
    // {
    //     $recommendedProducts = $this->userRepository->recommendedProducts();
    //     return view('front.auth.register', compact('recommendedProducts'));
    // }
    public function showRegistrationForm(Request $request){
        $recommendedProducts = $this->userRepository->recommendedProducts();
        return view('front.auth.register', compact('recommendedProducts'));
    }

public function register(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|string|email|max:255|unique:users',
        'phone' => 'required|string|max:15|unique:users',
        'password' => 'required|string|min:8',
    ]);

    $user = User::create([
        'name' => $request->name,
        'email' => $request->email,
        'phone' => $request->phone,
        'password' => Hash::make($request->password),
        'email_otp' => rand(100000, 999999),
        'phone_otp' => rand(100000, 999999),
    ]);

    // Send OTP to email
    Mail::to($user->email)->send(new OtpMail($user->email_otp));

    // Send OTP to phone via Twilio
    $sid = config('services.twilio.sid');
    $token = config('services.twilio.token');
    $twilio = new Client($sid, $token);
    $twilio->messages->create($user->phone, [
        'from' => config('services.twilio.from'),
        'body' => 'Your OTP code is ' . $user->phone_otp
    ]);

    return redirect()->route('verify.otp')->with('user', $user);
}


    // public function create(Request $request)
    // {
    //     $request->validate([
    //         'fname' => 'required|string',
    //         'lname' => 'required|string',
    //         'email' => 'required|email|unique:users,email',
    //         'mobile' => 'required|integer|digits:10|unique:users,mobile',
    //         'password' => 'required|string|min:2|max:100',
    //     ]);

    //     $storeData = $this->userRepository->create($request->except('_token'));

    //     if ($storeData) {
    //         // $credentials = $request->only('email', 'password');

    //         // if (Auth::attempt($credentials)) {
    //         //     // return redirect()->intended('home');
    //         //     return redirect()->url('home');
    //         // }

    //         return redirect()->route('front.user.login')->with('success', 'Account created successfully');
    //     } else {
    //         return redirect()->route('front.user.register')->withInput($request->all())->with('failure', 'Something happened');
    //     }
    // }

    
// ...

public function create(Request $request)
{

    $request->validate([
        'fname' => 'required|string',
        'lname' => 'required|string',
        'email' => 'required|email|unique:users,email',
        'mobile' => 'required|integer|digits:10|unique:users,mobile',
        'password' => 'required|string|min:8',
    ]);

    //$otp = Str::random(6); // Generate a 6-character OTP
	$otp = mt_rand(100000, 999999);
    $user = User::create([
        //'name' => $request->name,
        'fname' => $request->fname,
        'lname' => $request->lname,
        'email' => $request->email,
        'mobile' => $request->mobile,
        'password' => Hash::make($request->password),
        'otp' => $otp, // Save the OTP to the user record
    ]);

	$query_calling_number = "6291117317";
                
        $sms_entity_id = "1701159671476365690";
        $sms_template_id = "1707172130660470733";
        

        $myMessage = urlencode('Your OTP for KGA Electronics login is '.$otp.' Please enter this code on the website to proceed Thank you The KGA Electronics Team AMMRTL ');


        $sms_url = 'https://sms.bluwaves.in/sendsms/bulk.php?username=ammrllp&password=123456789&type=TEXT&sender=AMMRTL&mobile='.$user->mobile.'&message='.$myMessage.'&entityId='.$sms_entity_id.'&templateId='.$sms_template_id;

        // // echo $myMessage; die;

        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $sms_url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        // echo '<pre>'; echo $response;
	
	
	
    // Ensure email is correctly retrieved
    $email = $request->email;

    // Prepare the data for the email
    $data = ['otp' => $otp];

    // Send the email with the OTP
    Mail::send("emails.otp", $data, function ($message) use ($email) {
        $message->to($email)
                ->subject('Your OTP Code')
                ->from('info@milaapp.in');
    });
session(['email' => $request->email]);
    return redirect()->route('front.user.otp')->with('success', 'User registered successfully. Please check your email or phone for the OTP.');
}

	public function showVerifyForm(Request $request)
	{
		return view('front.auth.otp-verify');
	}
public function verifyOtp(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'otp' => 'required|string|size:6',
    ]);

    $user = User::where('email', $request->email)->where('otp', $request->otp)->first();

    if ($user) {
        // OTP is correct, log the user in
        Auth::login($user);

        // Clear the OTP
        $user->otp = null;
        $user->save();
		$email = $request->email; 
		 $body = "Welcome to KGA Electronics. Thank you for logging in. Explore our latest gadgets and track your orders with ease. Happy shopping!";
            $data = ['body' => $body];
	 	Mail::send("emails.welcome", $data, function ($message) use ($email) {
        	$message->to($email)
				->subject('"Welcome to KGA Electronics')
					 ->from('info@milaapp.in');
    	});
		
		
		$query_calling_number = "6291117317";
                
        $sms_entity_id = "1701159671476365690";
        $sms_template_id = "1707172130671122318";
        

        $myMessage = urlencode('Welcome to KGA Electronics Thank you for logging in. Explore our latest gadgets and track your orders with ease. Happy shopping! AMMRTL');


        $sms_url = 'https://sms.bluwaves.in/sendsms/bulk.php?username=ammrllp&password=123456789&type=TEXT&sender=AMMRTL&mobile='.$user->mobile.'&message='.$myMessage.'&entityId='.$sms_entity_id.'&templateId='.$sms_template_id;

        // // echo $myMessage; die;

        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $sms_url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $response = curl_exec($curl);
        curl_close($curl);
		
		
		
        return redirect()->route('home')->with('success', 'Logged in successfully');
    } else {
        return back()->withErrors(['otp' => 'Invalid OTP'])->withInput();
    }
}
    public function verifyOtp1(Request $request)
    {
        $user = User::find($request->user_id);
    
        if ($user->email_otp == $request->email_otp && $user->phone_otp == $request->phone_otp) {
            $user->is_verified = true;
            $user->email_otp = null;
            $user->phone_otp = null;
            $user->save();
    
            Auth::login($user);
    
            return redirect()->route('home')->with('status', 'Registration successful');
        } else {
            return redirect()->back()->withErrors('Invalid OTP');
        }
    }
    


    public function check(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
            'password' => 'required|string|min:2|max:100',
        ]);

        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            return redirect()->to($request->back_url)->with('success', 'Login Successful');
            // return redirect()->url('home');
        } else {
            return redirect()->route('front.user.login')->withInput($request->all())->with('failure', 'Please enter valid credentials');
        }
    }

	public function forgotPassword(Request $request)
    {
        return view('auth.passwords.email');
    }

    public function order(Request $request)
    {
        $data = $this->userRepository->orderDetails();
        return view('front.profile.order', compact('data'));
    }

    public function coupon(Request $request)
    {
        $data = $this->userRepository->couponList();
        return view('front.profile.coupon', compact('data'));
    }

    public function address(Request $request)
    {
        $data = $this->userRepository->addressById(Auth::guard('web')->user()->id);
        if ($data) {
            return view('front.profile.address', compact('data'));
        } else {
            return view('front.404');
        }
    }

    public function addressCreate(Request $request)
    {
        $request->validate([
            "user_id" => "required|integer",
            "address" => "required|string|max:255",
            //"landmark" => "required|string|max:255",
            "lat" => "nullable",
            "lng" => "nullable",
            "type" => "required|integer",
            "state" => "required|string",
            "city" => "required|string",
            "country" => "required|string",
            "pin" => "required|integer|digits:6",
            "type" => "required|integer",
        ], [
          //  "lat.*" => "Please enter Location",
          //  "lng.*" => "Please enter Location"
        ]);

        $params = $request->except('_token');
        $storeData = $this->userRepository->addressCreate($params);

        if ($storeData) {
            return redirect()->route('front.user.address');
        } else {
            return redirect()->route('front.user.address.add')->withInput($request->all());
        }
    }
	 public function addressEdit(Request $request, $id)
    {
        $data = Address::where('id',$id)->first();
        if ($data) {
            return view('front.profile.address-edit', compact('data'));
        } else {
            return redirect()->route('front.user.address')->with('failure', 'Something happened');
        }
    }
    public function addressUpdate(Request $request, $id)
    {
		
		 $request->validate([
            "user_id" => "required|integer",
            "address" => "required|string|max:255",
            //"landmark" => "required|string|max:255",
            "lat" => "nullable",
            "lng" => "nullable",
            "type" => "required|integer",
            "state" => "required|string",
            "city" => "required|string",
            "country" => "required|string",
            "pin" => "required|integer|digits:6",
            "type" => "required|integer",
        ], [
          //  "lat.*" => "Please enter Location",
          //  "lng.*" => "Please enter Location"
        ]);
        $params = $request->except('_token');
        $updateData = $this->userRepository->addressUpdate($id,$params);
        if ($updateData) {
            return redirect()->route('front.user.address.edit', ['id' => $id])->with('success', 'Address updated successfully');
            
        } else {
            return redirect()->route('front.user.address')->with('failure', 'Something happened');
        }
    }
    public function addressDelete(Request $request, $id)
    {
        $data = Address::where('id',$id)->delete();

        if ($data) {
            return redirect()->route('front.user.address')->with('success', 'Address removed');
        } else {
            return redirect()->route('front.user.address')->with('failure', 'Something happened');
        }
    }
    public function updateProfile(Request $request)
    {
        $request->validate([
            "fname" => "required|string|max:255",
            "lname" => "required|string|max:255",
            "mobile" => "required|integer|digits:10",
        ], [
            "mobile.*" => "Please enter a valid 10 digit mobile number"
        ]);

        $params = $request->except('_token');
        $storeData = $this->userRepository->updateProfile($params);

        if ($storeData) {
            return redirect()->route('front.user.manage')->with('success', 'Profile updated successfully');
        } else {
            return redirect()->route('front.user.manage')->withInput($request->all())->with('failure', 'Something happened. Try again');
        }
    }

    public function updatePassword(Request $request)
    {
        $request->validate([
            "old_password" => "required|string|max:255",
            "new_password" => "required|string|max:255|same:confirm_password",
            "confirm_password" => "required|string|max:255",
        ]);

        $params = $request->except('_token');
        $storeData = $this->userRepository->updatePassword($params);

        if ($storeData) {
            return redirect()->route('front.user.manage')->with('success', 'Password updated successfully');
        } else {
            return redirect()->route('front.user.manage')->withInput($request->all())->with('failure', 'Something happened');
        }
    }

    public function wishlist(Request $request)
    {
        $data = $this->userRepository->wishlist();
        if ($data) {
            return view('front.profile.wishlist', compact('data'));
        } else {
            return view('front.404');
        }
    }

    public function invoice(Request $request, $id)
    {
        $data = $this->orderRepository->listById($id);
        return view('front.profile.invoice', compact('data'));
    }

    public function orderCancel(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "orderId" => "required | integer",
            "cancellationReason" => "required | string"
        ]);

        if (!$validator->fails()) {
            $order = Order::findOrFail($request->orderId);
            $order->status = 5;
            $order->orderCancelledBy = auth()->guard('web')->user()->id;
            $order->orderCancelledReason = $request->cancellationReason;
            $order->save();

            return redirect()->back()->with('success', 'You have cancelled your order');
        } else {
            return redirect()->back()->with('failure', $validator->errors()->first());
        }
    }
}
