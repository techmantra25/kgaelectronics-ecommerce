@extends('admin.layouts.app')

@section('page', 'FAQ detail')

@section('content')
<section>
    <div class="row">
        <div class="col-sm-8">
            <div class="card">    
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <p class="text-muted small mb-1">Question</p>
                            <p class="text-dark small">{{$data->question}}</p>

                            <p class="text-muted small mb-1">Answer</p>
                            <p class="text-dark small">{{$data->answer}}</p>
                        </div>
                    </div>  
                </div>
            </div>
        </div>

        <div class="col-sm-4">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ route('admin.faq.update', $data->id) }}" enctype="multipart/form-data">
                    @csrf
                        <h4 class="page__subtitle">Edit</h4>
                        <div class="form-group mb-3">
                            <label class="label-control">Question </label>
                            <textarea name="question" class="form-control">{{$data->question}}</textarea>
                            @error('question') <p class="small text-danger">{{ $message }}</p> @enderror
                        </div>
                        <div class="form-group mb-3">
                            <label class="label-control">Answer </label>
                            <textarea name="answer" class="form-control">{{$data->answer}}</textarea>
                            @error('answer') <p class="small text-danger">{{ $message }}</p> @enderror
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-sm btn-danger">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection