@extends('layouts.app')
@section('page', 'Home')
@section('content')
<style>
    .color_holder {
        height: 20px;
        width: 20px;
        border-radius: 50%
    }
    .product__color {
        display: flex;
        flex-wrap: wrap;
        padding: 0 20px 20px;
        align-items: center;
        justify-content: center;
    }
    .color-holder {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        flex: 0 0 20px;
        margin-right: 7px;
        box-shadow: 0px 5px 10px rgb(0 0 0 / 10%);
    }
    @media(max-width: 575px) {
        .color-holder {
            width: 15px;
            height: 15px;
            flex: 0 0 15px;
        }
        .product__color {
            justify-content: center;
        }
    }
</style>
<!-- <section id="home" class="home-banner p-0">
    <div class="home-banner__slider swiper-container">
        <div class="slider swiper-wrapper">
			@foreach ($banner as $item)
                @php
                    $banImgVal = str_replace('public/','',$item->file_path);
                @endphp
                <div class="home-banner__slider-single swiper-slide">
                    
                        @if ($item->type == 'video')
                        <div class="video__wrapper">
                            <video id="onn-video" width="320" height="240" autoplay muted loop playsinline>
                                <source src="{{ asset($banImgVal) }}" type="video/mp4">
                                Your browser does not support the video tag.
                            </video>
                        </div>
                        @else
                        <div class="video__wrapper">
                            <a href="#">
                                <img src="{{ asset($banImgVal) }}" />
                            </a>
                        </div>
                        @endif
                    
                </div>
            @endforeach            
        </div>
        <div class="swiper-pagination"></div>
    </div>
</section> -->

<section class="home-banner-section">
    <div class="container">
        <div class="row align-items-stretch">
            <div class="col-12">
                <div class="product-image text-center">
                    <h1>FHD LED TV</h1>
                </div>
            </div>
            <div class="col-md-3">
                <div class="image-description">
                    <ul>
                        <li><img src="{{asset('img/hdmi-port.png')}}"><p>HDMI</p></li>
                        <li><img src="{{asset('img/aspect-ratio.png')}}"><p>Aspect Ratio</p></li>
                        <li><img src="{{asset('img/usb.png')}}"><p>USB</p></li>
                        <li><img src="{{asset('img/av_cable.png')}}"><p>AV</p></li>
                        <li><img src="{{asset('img/speaker.png')}}"><p>Loud Bass</p></li>
                        <li><img src="{{asset('img/signal-tower.png')}}"><p>RF</p></li>
                    </ul>
                    <p>Full HD 1080p Smart TV with AMD FreeSync, Apple AirPlay and Chromecast Built-in, Alexa Compatibility, D40f-J09, 2022 Model</p>
                    <p>From* <span class="price">₹1300</span></p>
                    <a href="#" class="latest-btm mt-auto">Order Now</a>
                </div>
            </div>

            <div class="col-md-6">
                <div class="product-image text-center">
                    <figure>
                        <img src="{{asset('img/kga_tv.png')}}">
                    </figure>
                    
                </div>
            </div>
            <div class="col-md-3">
                <ul class="speci-list">
                    <li>
                        <figure>
                            <img src="{{asset('img/material.svg')}}">
                        </figure>
                        <figcaption>
                            <h5>Material</h5>
                            <p>ABS Plastic</p>
                        </figcaption>
                    </li>
                    <li>
                        <figure>
                            <img src="{{asset('img/voltage.svg')}}">
                        </figure>
                        <figcaption>
                        <h5>Voltage</h5>
                            <p>240 Volts</p>
                        </figcaption>
                    </li>
                    <li>
                        <figure>
                            <img src="{{asset('img/speed.svg')}}">
                        </figure>
                        <figcaption>
                            <h5>Number of Speeds</h5>
                            <p>3</p>
                        </figcaption>
                    </li>
                    <li>
                        <figure>
                            <img src="{{asset('img/wattage.svg')}}">
                        </figure>
                        <figcaption>
                        <h5>Wattage</h5>
                            <p>550 Watts</p>
                        </figcaption>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row align-items-center">
            <div class="col-sm-3">
                <div class="scroller mobile-only">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 91 91" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M45.33 90a1.5 1.5 0 0 1-1.5-1.5V68.2a1.5 1.5 0 0 1 3 0v20.26a1.5 1.5 0 0 1-1.5 1.54z" fill="#000000" data-original="#000000"></path><path d="M45.33 90a1.5 1.5 0 0 1-1-.38l-9-7.88a1.5 1.5 0 1 1 2-2.25l9 7.88a1.49 1.49 0 0 1 .15 2.11 1.52 1.52 0 0 1-1.15.52z" fill="#000000" data-original="#000000"></path><path d="M45.33 90a1.5 1.5 0 0 1-1-2.63l9-7.88a1.5 1.5 0 1 1 2 2.25l-9 7.88a1.47 1.47 0 0 1-1 .38zM50.86 60.73H39.79a15.13 15.13 0 0 1-15.11-15.11v-29A15.13 15.13 0 0 1 39.79 1.46h11.07A15.12 15.12 0 0 1 66 16.57v29.05a15.12 15.12 0 0 1-15.14 15.11zM39.79 4.46a12.12 12.12 0 0 0-12.11 12.11v29.05a12.13 12.13 0 0 0 12.11 12.11h11.07A12.12 12.12 0 0 0 63 45.62v-29A12.12 12.12 0 0 0 50.86 4.46z" fill="#000000" data-original="#000000"></path><path d="M45.33 26.37a1.5 1.5 0 0 1-1.5-1.5v-7.53a1.5 1.5 0 0 1 3 0v7.53a1.5 1.5 0 0 1-1.5 1.5z" fill="#000000" data-original="#000000"></path></g></svg>
                    <span>Scroll Down</span>
                </div>
                <div class="scroller">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 91 91" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M45.33 90a1.5 1.5 0 0 1-1.5-1.5V68.2a1.5 1.5 0 0 1 3 0v20.26a1.5 1.5 0 0 1-1.5 1.54z" fill="#000000" data-original="#000000"></path><path d="M45.33 90a1.5 1.5 0 0 1-1-.38l-9-7.88a1.5 1.5 0 1 1 2-2.25l9 7.88a1.49 1.49 0 0 1 .15 2.11 1.52 1.52 0 0 1-1.15.52z" fill="#000000" data-original="#000000"></path><path d="M45.33 90a1.5 1.5 0 0 1-1-2.63l9-7.88a1.5 1.5 0 1 1 2 2.25l-9 7.88a1.47 1.47 0 0 1-1 .38zM50.86 60.73H39.79a15.13 15.13 0 0 1-15.11-15.11v-29A15.13 15.13 0 0 1 39.79 1.46h11.07A15.12 15.12 0 0 1 66 16.57v29.05a15.12 15.12 0 0 1-15.14 15.11zM39.79 4.46a12.12 12.12 0 0 0-12.11 12.11v29.05a12.13 12.13 0 0 0 12.11 12.11h11.07A12.12 12.12 0 0 0 63 45.62v-29A12.12 12.12 0 0 0 50.86 4.46z" fill="#000000" data-original="#000000"></path><path d="M45.33 26.37a1.5 1.5 0 0 1-1.5-1.5v-7.53a1.5 1.5 0 0 1 3 0v7.53a1.5 1.5 0 0 1-1.5 1.5z" fill="#000000" data-original="#000000"></path></g></svg>
                    <span>Scroll Down</span>
                </div>
            </div>
            <div class="col-sm-6">
                <p>Versatility and performance collide with the new D-Series FHD Smart TV that comes loaded with a full array backlight for better contrast and uniformity, brilliant 1080p Full HD resolution and an ultra-fast VIZIO IQ processor with support for immersive audio pass-through for Dolby Atmos and DTS:X.</p>
            </div>
            <div class="col-sm-3 text-right">
                <a href="#" class="text-btm-new">
                    Discover More
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512.009 512.009" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M508.625 247.801 392.262 131.437c-4.18-4.881-11.526-5.45-16.407-1.269-4.881 4.18-5.45 11.526-1.269 16.407.39.455.814.88 1.269 1.269l96.465 96.582H11.636C5.21 244.426 0 249.636 0 256.063s5.21 11.636 11.636 11.636H472.32l-96.465 96.465c-4.881 4.18-5.45 11.526-1.269 16.407s11.526 5.45 16.407 1.269c.455-.39.88-.814 1.269-1.269l116.364-116.364c4.511-4.537 4.511-11.867-.001-16.406z" fill="#000000" data-original="#000000" class=""></path></g></svg>
                </a>
            </div>
        </div>
    </div>
</section>


<section class="first_category">
    <div class="category_block">
        <div class="category_content">
            <h2>Sports Bottle</h2>
            <h4>304 stainless steel</h4>
            <span class="price">Starting  ₹ 499*</span>

            <div class="d-block mt-auto">
                <div class="swiper cat_slide">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <figure>
                                <img src="{{asset('img/bottle_1.png')}}">
                            </figure>
                        </div>
                        <div class="swiper-slide">
                            <figure>
                                <img src="{{asset('img/bottle_2.png')}}">
                            </figure>
                        </div>
                        <div class="swiper-slide">
                            <figure>
                                <img src="{{asset('img/bottle_3.png')}}">
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- <div class="category_btn">
            <a href="#" class="">
                <span>Buy Now</span> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
            </a>
        </div> -->
        <!-- Swiper -->
        <!-- <div class="swiper-container two">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="slider-image">
                        <img src="{{asset('img/bottle1.png')}}" alt="slide 1">
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="slider-image">
                        <img src="{{asset('img/bottle2.png')}}" alt="slide 2">
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="slider-image">
                        <img src="{{asset('img/bottle3.png')}}" alt="slide 3">
                    </div>
                </div>
            </div>
            <div class="swiper-pagination"></div>
        </div> -->
        <div class="category_slider">
            <div class="swiper cat_thumbnail">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <figure class="bottle_img">
                            <img src="{{asset('img/bottle_1.png')}}">
                        </figure>
                    </div>
                    <div class="swiper-slide">
                        <figure class="bottle_img">
                            <img src="{{asset('img/bottle_2.png')}}">
                        </figure>
                    </div>
                    <div class="swiper-slide">
                        <figure class="bottle_img">
                            <img src="{{asset('img/bottle_3.png')}}">
                        </figure>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="category_feture">
            <ul>
                <li>
                    <h5>Leak Proof</h5>
                </li>
                <li>
                    <h5>304 Stainless Steel</h5>
                </li>
                <li>
                    <h5>Tough Coating</h5>
                </li>
                <li>
                    <h5>Heavy duty</h5>
                </li>
                <li>
                    <h5>Durable</h5>
                </li>
            </ul>
            <a href="#" class="btn">Add to cart <span><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg></span></a>
        </div>
    </div>

    <div class="small_cat">
        <div class="heading">
            <h2 class="text-center">Wireless Stereo<br/><span>Earbuds</span></h2>
            <h4>New Arrival</h4>
        </div>
        
        <img src="{{asset('img/kga_headphone.png')}}">

        <div class="row align-items-end">
            <div class="col-6 text-right">
                <span class="cart_area">
                    <span>₹ 499</span><br/>
                    <a href="#">Add to cart <span><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg></span></a>
                </span>
            </div>
            <div class="col-6">
                <a href="" class="withlist_btn">Add to wish list <span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span></a>
            </div>
        </div>
    </div>
</section>


<section class="frying_section">
    <div class="container">
        <div class="row align-items-center">
            <div class="panel_right">

                <div id="pan1" class="prod_details">
                    <div class="product_content">
                        <h2>Non-Stick Cookware<br/>Dosa Tawa</h2>
                        <h4>3mm Extra Thick Plate with Induction Base, Long Handle, Virgin Grade Aluminium, PFOA/Heavy Metals Free, Pearl Red 3 Layers Reinforced Non-Stick Coating (Size: 280mm)</h4>
                        <div class="price">₹990</div>

                        <div class="thumb_banner">
                            <div class="swiper mySwiper">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <img src="{{asset('img/pan1.png')}}">
                                    </div>
                                    <div class="swiper-slide">
                                        <img src="{{asset('img/pan2.png')}}">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <h6>Available Size</h6>

                        <div class="size_box">
                            <label class="box_item"><input type="radio" name="size"><span>250 mm</span></label>
                            <label class="box_item"><input type="radio" name="size"><span>280 mm</span></label>
                            <label class="box_item"><input type="radio" name="size"><span>305 mm</span></label>
                        </div>
                        <a href="#" class="btn">Add to cart <span><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg></span></a>
                    </div>
                    <div class="product_thumb">
                        <div class="swiper mySwiper2">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <figure>
                                        <img src="{{asset('img/pan1.png')}}">
                                    </figure>
                                </div>
                                <div class="swiper-slide">
                                    <figure>
                                        <img src="{{asset('img/pan2.png')}}">
                                    </figure>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="pan3" class="prod_details">
                    <div class="product_content">
                        <h2>Non-Stick Cookware<br/>Frying Pan</h2>
                        <h4>With Glass Lid With Induction Base, Long Handle, Virgin Grade Aluminium, PFOA/Heavy Metals Free, 3mm Thickness, Pearl Red 3 Layers Reinforced Non-Stick Coating, 2.75L</h4>
                        <div class="price">₹990</div>

                        <div class="thumb_banner">
                            <div class="swiper mySwiper3">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <img src="{{asset('img/pan3.png')}}">
                                    </div>
                                    <div class="swiper-slide">
                                        <img src="{{asset('img/pan4.png')}}">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <h6>Available Size</h6>

                        <div class="size_box">
                            <label class="box_item"><input type="radio" name="size"><span>0.5L</span></label>
                            <label class="box_item"><input type="radio" name="size"><span>1L</span></label>
                            <label class="box_item"><input type="radio" name="size"><span>1.7L</span></label>
                            <label class="box_item"><input type="radio" name="size"><span>2.2L</span></label>
                            <label class="box_item"><input type="radio" name="size"><span>2.8L</span></label>

                        </div>
                        <a href="#" class="btn">Add to cart <span><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg></span></a>
                    </div>
                    <div class="product_thumb">
                        <div class="swiper mySwiper4">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <figure>
                                        <img src="{{asset('img/pan3.png')}}">
                                    </figure>
                                </div>
                                <div class="swiper-slide">
                                    <figure>
                                        <img src="{{asset('img/pan4.png')}}">
                                    </figure>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="panel_left">
                <ul>
                    <li data-thumb="pan1">
                        <img src="{{asset('img/pan1.png')}}">
                    </li>
                    <li data-thumb="pan3">
                        <img src="{{asset('img/pan3.png')}}">
                    </li>
                    <li data-thumb="pan5">
                        <img src="{{asset('img/pan5.png')}}">
                    </li>
                    <li data-thumb="pan7">
                        <img src="{{asset('img/pan7.png')}}">
                    </li>
                    <li data-thumb="pan9">
                        <img src="{{asset('img/pan10.png')}}">
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>


<section class="mixer_section">
    <img src="{{asset('img/mixer_bg.png')}}">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center"><h2>Mixer Grinder</h2></div>
        </div>
        <div class="swiper mixer_slide">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="row">
                        <div class="col-sm-3 text-center mixer_content">
                            <h3>KGA Royal Admiral Mixer Grinder</h3>
                            <p>Starting ₹ 2,219</p>
                            <a href="#" class="btn">Add to cart <span><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg></span></a>
                        </div>
                        <div class="col-sm-4">
                            <img src="{{asset('img/mixer.png')}}" class="mixer_img">
                        </div>
                        <div class="col-sm-3"></div>
                    </div>
                </div>

                <div class="swiper-slide">
                    <div class="row">
                        <div class="col-sm-3 text-center mixer_content">
                            <h3>KGA Royal Admiral Mixer Grinder</h3>
                            <p>Starting ₹ 2,219</p>
                            <a href="#" class="btn">Add to cart <span><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg></span></a>
                        </div>
                        <div class="col-sm-4">
                            <img src="{{asset('img/mixer.png')}}" class="mixer_img">
                        </div>
                        <div class="col-sm-3"></div>
                        
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>


<section class="category-section">
    <div class="cat-left">
        <figure>
            <img src="{{asset('img/kadai.svg')}}">
        </figure>
        <figcaption>
            <h3>Deep Kadai</h3>
            <p>Collection</p>
        </figcaption>
    </div>
    <div class="cat-product">
        <div class="product-holder">
            <div class="pro-details-place">
                <p>KGA Utensils are high quality and are a perfect choice for your modern kitchens.</p>
                <div class="proprice">₹1100</div>
                <a href="#" class="add-fav-icon"><i class="flaticon-heart"></i> Add To Favs</a>
            </div>
            <div class="pro-image">
                <img src="{{asset('img/DEEP-KADAI.png')}}">
            </div>
            <div class="Pro-name">
                <h2>Non-Stick Cookware Deep Kadai </h2>
                <a href="#" class="latest-btm">Order Now</a>
            </div>
        </div>
    </div>
</section>

<section class="category-section cat-bottle-color">

    <div class="cat-product">
        <div class="product-holder">
            <div class="pro-details-place">
                <p>KGA Bottle are high quality and are a perfect choice for the world traveller.</p>
                <div class="proprice">₹499</div>
                <a href="#" class="add-fav-icon"><i class="flaticon-heart"></i> Add To Favs</a>
            </div>
            <div class="pro-image">
                <img src="{{asset('img/kga-bottle.png')}}">
            </div>
            <div class="Pro-name">
                <h2>Travel Stainless Steel Sports Water Bottle </h2>
                <a href="#" class="latest-btm">Order Now</a>
            </div>
        </div>
    </div>
    <div class="cat-left">
        <figure>
            <img src="{{asset('img/waterbottle.svg')}}">
        </figure>
        <figcaption>
            <h3>Bottle</h3>
            <p>Collection</p>
        </figcaption>
    </div>
</section>

<section class="quater_banner">
    <div class="container">
        <div class="row m-0 ">
			@foreach ($featureBanner as $item)
                @php
                    $banImgVal = str_replace('public/','',$item->file_path);
                @endphp
			 @if ($item->type == 'video')
                        <div class="col-sm-4 mb-3  mb-sm-0">
                            <video id="onn-video" width="320" height="240" autoplay muted loop playsinline>
                                <source src="{{ asset($banImgVal) }}" type="video/mp4">
                                Your browser does not support the video tag.
                            </video>
                        </div>
                        @else
            <div class="col-sm-4 mb-3  mb-sm-0">
                <a href="#" class="image-style">
                    <img src="{{ asset($banImgVal) }}" />
                </a>
            </div>
			@endif
            {{--<div class="col-sm-4 mb-3  mb-sm-0">
                <a href="#" class="image-style">
                    <img src="img/kga_banner_4.png" />
                </a>
            </div>
            <div class="col-sm-4">
                <a href="#" class="image-style">
                    <img src="img/kga_banner_5.png" />
                </a>
            </div>--}}
			 @endforeach           
        </div>
    </div>
</section>
<section id="tranding" class="home-product">
    <div class="container">
        <div class="row align-items-center m-0 mb-2 mb-sm-4">
            <div class="col-sm-12">
                <h2 class="">Trending Products</h2>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="home-product__holder">
            <!-- <div class="home-product__holder__left">
                <h2 class="home-product__holder__title">Trending <strong>Products</strong></h2>
            </div> -->
    
            <div class="home-product__holder__right">
                <div class="home_product__left">
					@foreach ($poster as $item)
                @php
                    $banImgVal = str_replace('public/','',$item->file_path);
                @endphp
                    <figure>
                        <a href="#" class="image-style">
                            <img src="{{$banImgVal}}">
                        </a>
                    </figure>
					@endforeach
                </div>
                <div class="home-product__slider">
                    @foreach ($products as $productKey => $productValue)
                        @php
                            $imgVal = str_replace('public/','',$productValue->image);
                        @endphp
                        <a href="{{ route('front.product.detail', $productValue->slug) }}" class="home-product__single">
                            <figure>
                                <img src="{{asset($imgVal)}}" />
                            </figure>
                            <figcaption>
                                <h4>{{$productValue->name}}</h4>
                                <!--<h6>Style # OF {{$productValue->style_no}}</h6>-->
                                <h5> <del>&#8377;{{$productValue->price}}</del> &#8377;{{$productValue->offer_price}}</h5>
                                
                            </figcaption>
                            {!! variationColors($productValue->id, 5) !!}
                        </a>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>

<section class="half_banner">
    <div class="container">
        <div class="row m-0">
			@foreach ($promotion as $item)
                @php
                    $banImgVal = str_replace('public/','',$item->file_path);
                @endphp
            <div class="col-sm-6 mb-3 mb-sm-0">
                <a href="#" class="image-style">
                    <!-- <img src="img/kga_banner_1.png" /> -->
                    <img src="{{$banImgVal}}" />
                </a>
            </div>
			@endforeach
            {{--<div class="col-sm-6">
                <a href="#" class="image-style">
                    <!-- <img src="img/kga_banner_2.png" /> -->
                    <img src="img/add-banner21000x1000.jpg" />
                </a>
            </div>--}}
        </div>
    </div>
</section>


<section class="review-section">
    <div class="container">
        <div class="row align-items-center m-0 mb-2 mb-sm-4">
            <div class="col-sm-12">
                <h2 class="">Product Review</h2>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row m-0">
			@foreach ($productReview as $item)
                @php
                    $banImgVal = str_replace('public/','',$item->thumbnail_image);
			       $banvideoVal = str_replace('public/','',$item->video);
                @endphp
            <div class="col-sm-6 mb-3 mb-sm-0">
				@if(!empty($item->video_link))
                <a class="review_thumb" target="_blank" href="{{$item->video_link}}">
					@else
					 <a href="{{$banvideoVal}}" data-fancybox class="video_thumb">
						 @endif
                    <figure>
                        <img src="img/review1.jpg">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!-- Font Awesome Pro 5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) --><path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"/></svg>
                    </figure>
                    <figcaption>
                        <h4>{{$item->title}}</h4>
                        <p>{!!$item->description!!}</p>
                    </figcaption>
                </a>
            </div>
			@endforeach
           {{-- <div class="col-sm-6">
                <a class="review_thumb" data-fancybox href="https://www.youtube.com/watch?v=UYldyU6qf38">
                    <figure>
                        <img src="img/review2.jpg">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!-- Font Awesome Pro 5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) --><path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"/></svg>
                    </figure>
                    <figcaption>
                        <h4>KGA Family - Customer Feedback Pavit</h4>
                        <p>Pavit, one of our satisfied customers shares her experience with KGA Home Appliances and how she is living a healthy comfortable life by using KGA products.</p>
                    </figcaption>
                </a>
            </div>--}}
        </div>
    </div>
</section>


<section class="video-section">
    <div class="container">
        <div class="row align-items-center m-0 mb-2 mb-sm-4">
            <div class="col-sm-12">
                <h2 class="">Product Videos</h2>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row m-0">
			@foreach ($productVideo as $item)
                @php
                    $banImgVal = str_replace('public/','',$item->file_path);
			       $banvideoVal = str_replace('public/','',$item->video);
                @endphp
            <div class="col-sm-4 mb-3 mb-sm-0">
                <a href="{{$banvideoVal}}" data-fancybox class="video_thumb">
                    <figure>
                        <img src="{{$banImgVal}}">
                    </figure>
                    <figcaption>
                        <h2>{{$item->title}}</h2>
                        <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M100 50C100 77.6142 77.6142 100 50 100C22.3858 100 0 77.6142 0 50C0 22.3858 22.3858 0 50 0C77.6142 0 100 22.3858 100 50ZM2.5 50C2.5 76.2335 23.7665 97.5 50 97.5C76.2335 97.5 97.5 76.2335 97.5 50C97.5 23.7665 76.2335 2.5 50 2.5C23.7665 2.5 2.5 23.7665 2.5 50Z" fill="#D9D9D9"/>
                            <path d="M37.6506 37.1603C37.6506 33.3113 41.8173 30.9056 45.1506 32.8301L67.6506 45.8205C70.984 47.745 70.984 52.5563 67.6506 54.4808L45.1506 67.4711C41.8173 69.3956 37.6506 66.99 37.6506 63.141L37.6506 37.1603Z" fill="#D9D9D9"/>
                        </svg>
                    </figcaption>
                </a>
            </div>
           {{-- <div class="col-sm-4 mb-3 mb-sm-0">
                <a href="https://www.youtube.com/watch?v=D3Fh-ARfn3w" data-fancybox class="video_thumb">
                    <figure>
                        <img src="img/video2.png">
                    </figure>
                    <figcaption>
                        <h2>KGA<br/>Induction</h2>
                        <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M100 50C100 77.6142 77.6142 100 50 100C22.3858 100 0 77.6142 0 50C0 22.3858 22.3858 0 50 0C77.6142 0 100 22.3858 100 50ZM2.5 50C2.5 76.2335 23.7665 97.5 50 97.5C76.2335 97.5 97.5 76.2335 97.5 50C97.5 23.7665 76.2335 2.5 50 2.5C23.7665 2.5 2.5 23.7665 2.5 50Z" fill="#D9D9D9"/>
                            <path d="M37.6506 37.1603C37.6506 33.3113 41.8173 30.9056 45.1506 32.8301L67.6506 45.8205C70.984 47.745 70.984 52.5563 67.6506 54.4808L45.1506 67.4711C41.8173 69.3956 37.6506 66.99 37.6506 63.141L37.6506 37.1603Z" fill="#D9D9D9"/>
                        </svg>
                    </figcaption>
                </a>
            </div>
            <div class="col-sm-4">
                <a href="https://www.youtube.com/watch?v=gdEY4C234ow" data-fancybox class="video_thumb">
                    <figure>
                        <img src="img/video3.png">
                    </figure>
                    <figcaption>
                        <h2>KGA<br/>Toaster</h2>
                        <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M100 50C100 77.6142 77.6142 100 50 100C22.3858 100 0 77.6142 0 50C0 22.3858 22.3858 0 50 0C77.6142 0 100 22.3858 100 50ZM2.5 50C2.5 76.2335 23.7665 97.5 50 97.5C76.2335 97.5 97.5 76.2335 97.5 50C97.5 23.7665 76.2335 2.5 50 2.5C23.7665 2.5 2.5 23.7665 2.5 50Z" fill="#D9D9D9"/>
                            <path d="M37.6506 37.1603C37.6506 33.3113 41.8173 30.9056 45.1506 32.8301L67.6506 45.8205C70.984 47.745 70.984 52.5563 67.6506 54.4808L45.1506 67.4711C41.8173 69.3956 37.6506 66.99 37.6506 63.141L37.6506 37.1603Z" fill="#D9D9D9"/>
                        </svg>
                    </figcaption>
                </a>
            </div>--}}
			@endforeach
        </div>
    </div>
</section>
@endsection
